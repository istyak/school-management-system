<?php
 ob_start();
 session_start();
 require_once 'dbconnect.php';
 
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: login.php");
  exit;
 }
 // select loggedin users detail
 $res=mysqli_query($con,"SELECT * FROM admin WHERE adminId=".$_SESSION['user']);
 $userRow=mysqli_fetch_array($res);
?>
<!doctype html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="icon" href="images/fevicon.png" type="image/gif">


		<!-- Stylesheet -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="style.css">	
		<title>Students | School Management System !</title>

	</head>
	<body>
		<div class="container-full">		
		<header>
			<div class="logo container">
				<div class="row">
					<div class="col-md-6"><a href="admin.php"><img src="images/logo.png" alt="" /></a></div>
					<div class="col-md-6">
						<div class="social float-right">
							<a href=""><img src="images/facebook.png" alt="" /></a>
							<a href=""><img src="images/twitter.png" alt="" /></a>
							<a href=""><img src="images/youtube.png" alt="" /></a>
							<a href=""><img src="images/google-plus.png" alt="" /></a>
						</div>
					</div>
				</div>
			</div>
			<div class="navigation" id="myHeader">
				<nav class="container">				
					<ul>
						<li><a href="admin.php">Dashboard</a></li>
						<li><a href="students.php">Students</a></li>
						<li class="active_nav"><a href="teachers.php">Teachers</a></li>
						<li><a href="">Result</a></li>
						<li><a href="">Notice</a></li>
						<li><a href="">Contact Us</a></li>
					</ul>
					<ul class="float-right login">
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>		
			</div>
				
		</header>		
		<div class="content container margin-top">
			<div class="row">
				<div class="col-md-12">	
					<div class="searchandadd">
						<div class="row">
							<div class="col-md-8">
								<div class="search_students">
									<form action="" method="post">
									<input name="id_search" type="text" class="form-control st_search" placeholder="Enter Student Id">					
									<button type="submit" class="sbtn btn btn-secondary mb-2 float-right">Search Teacher</button>
									</form>
								</div>
							</div>
							<div class="col-md-4">
								<button type="button" class="btn btn-secondary float-right">Add Teacher</button>			
							</div>
						</div>
					</div>
					
					<div class="single_content">
						<table class="table-responsive-lg table table-bordered table-hover">
						  <thead>
							<tr>
							  <th scope="col">#</th>
							  <th scope="col">First</th>
							  <th scope="col">Seconds</th>
							  <th scope="col">Last</th>
							  <th scope="col">Handle</th>
							</tr>
						  </thead>
						  <tbody>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>1</th>
							  <td>Mark</td>
							  <td>Mark</td>
							  <td>Otto</td>
							  <td>@mdo</td>
							</tr>
							<tr>
							  <th>2</th>
							  <td>Jacob</td>
							  <td>Jacob</td>
							  <td>Thornton</td>
							  <td>@fat</td>
							</tr>
							<tr>
							  <th>3</th>
							  <td>Larry the Bird</td>
							  <td>@twitter</td>
							  <td>@twitter</td>
							  <td>@fat</td>
							</tr>
						  </tbody>
						</table>
					</div>					
				</div>
			</div>
		</div>
		<?php include('footer.php'); ?>	
		
		
