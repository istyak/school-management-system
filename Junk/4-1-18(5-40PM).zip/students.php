<?php
 ob_start();
 session_start();
 require_once 'dbconnect.php';
 
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: login.php");
  exit;
 }
 // select loggedin users detail
 $res=mysqli_query($con,"SELECT * FROM admin WHERE adminId=".$_SESSION['user']);
 $userRow=mysqli_fetch_array($res);
?>
<!doctype html>
<html lang="en">
	<head>
		<!-- Required meta tags -->
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="icon" href="images/fevicon.png" type="image/gif">


		<!-- Stylesheet -->
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="style.css">	
		<title>Students | School Management System !</title>

	</head>
	<body>
	<?php include('includes/add_student.php'); ?>	
		<div class="container-full">		
		<header>
			<div class="logo container">
				<div class="row">
					<div class="col-md-6"><a href="admin.php"><img src="images/logo.png" alt="" /></a></div>
					<div class="col-md-6">
						<div class="social float-right">
							<a href=""><img src="images/facebook.png" alt="" /></a>
							<a href=""><img src="images/twitter.png" alt="" /></a>
							<a href=""><img src="images/youtube.png" alt="" /></a>
							<a href=""><img src="images/google-plus.png" alt="" /></a>
						</div>
					</div>
				</div>
			</div>
			<div class="navigation" id="myHeader">
				<nav class="container">				
					<ul>
						<li><a href="admin.php">Dashboard</a></li>
						<li class="active_nav"><a href="students.php">Students</a></li>
						<li><a href="teachers.php">Teachers</a></li>
						<li><a href="">Result</a></li>
						<li><a href="">Notice</a></li>
						<li><a href="">Contact Us</a></li>
					</ul>
					<ul class="float-right login">
						<li><a href="logout.php">Logout</a></li>
					</ul>
				</nav>		
			</div>
				
		</header>		
		<div class="content container margin-top15">
			<div class="row">
				<div class="col-md-12">	
					<div class="searchandadd">
						<div class="row">
							<div class="col-md-12">
								<div class="search_students">
									<form action="" method="post">
									<input name="id_search" type="text" class="form-control st_search" placeholder="Enter Student Id">					
									<div class="btn-toolbar float-right" role="toolbar" aria-label="Toolbar with button groups">
									  <div class="btn-group mr-2" role="group" aria-label="First group">										
										<button type="button" class="btn btn-secondary">Search Student</button>
									  </div>									  
									  <div class="btn-group" role="group" aria-label="Second group">
										<button data-toggle="modal" data-target=".modal_ad_student" type="button" class="btn btn-secondary float-right">+</button>	
									  </div>
									</div>
									</form>
								</div>
							</div>							
						</div>
					</div>
					
					<div class="single_content">
						<div class="student_table">							
							<?php
							$query = "SELECT * FROM student ORDER BY id ASC LIMIT 10";
							$result = mysqli_query($con,$query);
							echo "<table class='table-responsive-lg table table-bordered table-hover'>
						  <thead>
							<tr>
							  <th>#</th>
							  <th>Name</th>
							  <th>Student ID</th>
							  <th>Date of Birth</th>
							  <th>Course ID</th>
							  <th>Phone</th>
							  <th>Address</th>
							</tr>
						  </thead>"; 
							while($row = mysqli_fetch_array($result)){ 
							echo 
							 "<tbody><tr><th>" . $row['id'] 
							."</td><td>". $row['name'] 
							."</td><td>". $row['student_id'] 
							."</td><td>" .$row['dob']	
							."</td><td>" .$row['course_id']						
							."</td><td>" .$row['phone']						
							."</td><td>" .$row['addreess']						
							."</tr><tr>"; 
							}
							echo "</tbody></table>"; 
							mysqli_close($con);
						?>	
						</div>	
					</div>					
				</div>
			</div>
		</div>
		<?php include('footer.php'); ?>	
		
		
