		<footer>
			<div class="container">
				<div class="footer_top row">			
					<div class="col-md-4">
						<h4>About Us</h4>
						<p>Daffodil International University is a co-educational private university located in Dhanmondi, Dhaka, Bangladesh.</p>
						102 Mirpur Rd, Dhaka 1207
						<p>Daffodil International University Main Campus
						</br>Mobile : 013843546466</p>
					</div>					
					<div class="col-md-4">
						<h4>Useful Links</h4>
						<p>Birshreshtha Noor Mohammad Public College at Peelkhana, Dhaka is one of the most reputed educational institutions in Dhaka Metropolitan City. This institution is uniquely housed in a lush green shadowy environment with enviably safe surroundings.</p>
					</div>
					<div class="col-md-4 map">
						<h4>Google Map</h4>
						<img src="images/map.png" alt="" />
					</div>
				</div>
			</div>	
			<div class="footer_bottom">
				<div class="container">
					<h5>Copyright @ 43 Batch DIU</h5>
				</div>					
			</div>		
		</footer>
		</div>
		<script>
			window.onscroll = function() {myFunction()};
			var header = document.getElementById("myHeader");
			var sticky = header.offsetTop;
			function myFunction() {
			  if (window.pageYOffset >= sticky) {
				header.classList.add("sticky");
			  } else {
				header.classList.remove("sticky");
			  }
			}
		</script>
		<!-- JavaScript -->		
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.bundle.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>